class EventNode {
private:
	Event* data;
public:
	EventNode(Event* e){
		data = e;
	}
	EventNode* prev;
	EventNode* next;
	Event* getEvent(){
		return data;
	}
	EventNode* getNext(){
		return this->next;
	}
	EventNode* getPrev(){
		return this->prev;
	}
	void setNext(EventNode* node){
		this->next = node;
	}
	void setPrev(EventNode* node){
		this->prev = node;
	}
	std::string toString();
	~EventNode();
};

class EventList {
private:
	EventNode* head;
	EventNode* tail;
	int size;
public:
	EventList(){
		size = 0;
		head = nullptr;
		tail = nullptr;
	}
	EventList(EventNode* head){
		this->head = head;
		this->tail = head;
		size = 1;
	}
	int getSize(){ //returns size
		return size;
	}
	EventNode* getHead(){ //returns the head
		return head;
	}
	EventNode* getTail(){ //returns the head
		return tail;
	}
	void add(EventNode* e){ //adds an event to the linked list
		if(!tail){
			this->tail = e;
			this->head = e;
		}
		else{
			this->tail->setNext(e);
			this->tail = tail->next;
		}
		size++;
		}
	EventNode* get(int i){ //gets the ith member of the linked list
		EventNode* temp;
		temp = head;
		for(int j = 0; j < i; j++){
			temp = temp->next;
		}
		return temp;
	}
};

